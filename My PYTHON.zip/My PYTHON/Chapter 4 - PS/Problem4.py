l = [2,6,8,3]

print(sum(l))