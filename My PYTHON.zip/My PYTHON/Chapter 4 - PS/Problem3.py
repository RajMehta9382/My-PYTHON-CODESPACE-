a = (23,67,'harry')

a[2] = 'larry' #  ERROR - Tuples are immutable