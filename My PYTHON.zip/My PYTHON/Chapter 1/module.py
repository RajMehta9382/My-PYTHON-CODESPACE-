import pyjokes

# print("Printing jokes...")
# this prints a random joke
joke = pyjokes.get_joke()
print(joke)

"""
so thats it
thats my first program

"""
# SO THATS IT
# THANKS