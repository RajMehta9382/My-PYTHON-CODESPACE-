a = 1 # a is an integer

b = 3.56 # b is a floating point number

c = "jarvis" # c is a string

d = False # d is a boolean variable

e = None # e is a none type variable