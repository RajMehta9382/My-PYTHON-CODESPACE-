a = 1

b = 2

c  = 7

name = "jarvis"

print(a+b-c)