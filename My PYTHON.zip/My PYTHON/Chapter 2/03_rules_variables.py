a = 5

aaa = 5

jarvis = 5

_jarvis = 5

jar_vis = 5

# @jarvis = 5  invalid due to @ symbol

# j@rvis =  5  invalid due to @ symbol

# 0jarvis = 5  invalid due to 0 number

# jar vis = 5  invalid due to wide space