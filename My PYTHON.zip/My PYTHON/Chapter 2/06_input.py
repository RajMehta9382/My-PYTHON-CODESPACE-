a = input ("enter number 1: ")  # output of input is always a string
b = input ("enter number 2: ")
print ("number a is: ", a)
print ("number b is: ", b)
print("sum is ", a+b)  # "a" + "b" = ab

c = int(input ("enter number 1: "))  # its now a integer due to integer function
d = int(input ("enter number 2: "))
print ("number c is: ", c)
print ("number d is: ", d)
print("sum is ", c+d)  # c + d = c+d