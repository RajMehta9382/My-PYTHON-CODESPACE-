name = "jarvis is a good  boy and "

print(name.replace("  ", " ")) # doesn't changes the parent string, outputs a new string instead
print(name) # strings are immutable which means that you cannot change them by ececuting or running functions on them