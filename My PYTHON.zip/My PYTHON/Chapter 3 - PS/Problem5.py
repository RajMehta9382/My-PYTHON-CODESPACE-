letter = "Dear Harry, this python course is nice. Thanks!"

letter = "Dear Harry, \n\tThis python course is nice.\n\t\t\tThanks!"
print(letter)   # printed the newest variable having same variable name