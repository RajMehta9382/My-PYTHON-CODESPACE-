name = "jarvis is a good  boy and "

print(name.find("  ")) # outputs the index of that sub string in the parent string