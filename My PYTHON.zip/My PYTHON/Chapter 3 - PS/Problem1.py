name = input("Enter your name: ")
print(f"Good afternoon, {name}") # used f-string here