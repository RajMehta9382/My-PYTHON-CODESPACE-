a = 5

b = 5

print(a+b)