a = 34
b = 5
print("Remainder when a is divided by b is ", a % b)  # % is a module operator