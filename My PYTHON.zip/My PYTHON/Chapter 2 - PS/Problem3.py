a = input("Enter the value of a: ")
print(type(a))