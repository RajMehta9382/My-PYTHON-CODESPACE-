a = int(input("Enter your number: "))   
print("The square of the number is", a**2)  # sqaure- a**2 or a*a