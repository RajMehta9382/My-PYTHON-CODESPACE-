a = (1,45,342,3424,False, "Rohan", "Shivam") # A tuple is an immutable data type.
print(a)
print(type(a))

b = () # Empty tuple
print(type(b))

c = (3,) # Tuple with a single element --> 'insert a comma at end the of element'
print(type(c))