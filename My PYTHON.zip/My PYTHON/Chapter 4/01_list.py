friends = ['Apple','orange',7,302.07,False] # Lists can store any and multiple set of values
print(friends[0]) # Involves indexing

friends[0] = 'Grapes' # Unlike strings, lists are mutable
print(friends[0])

print(friends[1:4]) # List slicing