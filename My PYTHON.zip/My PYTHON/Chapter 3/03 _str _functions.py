name = "hello world"

print(len(name)) # includes wide space between string

print(name.endswith("rld"))

print(name.startswith("he"))

print(name.capitalize()) # only capitalize the first letter 

print(name.count("l"))

print(name.find("world")) # palce or index at which world lies

print(name.replace("world","python")) # replaces all the occurences 
a = "jarvis is a good good boy"
print(a.replace("good","bad"))