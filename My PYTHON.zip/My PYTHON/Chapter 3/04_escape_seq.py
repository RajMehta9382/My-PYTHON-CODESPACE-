a = "jarvis is a good boy\nbut not a bad boy" # '\n' is a esc seq charcater which changes the line
print(a)
b = "jarvis is a good boy\tbut not a bad boy" # '\t' --> tab space
print(b)
c = "jarvis is a good boy but not a \"bad\" boy" # '\"' --> double quote
print(c)