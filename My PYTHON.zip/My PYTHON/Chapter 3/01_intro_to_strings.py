a = 'jarvis' # Single quoted string 
b = "jarvis" # Double quoted string
c = '''jarvis''' # Triple quoted string

name = "jarvis"
nameshort = name[0:6]  
print (nameshort)
character1 = name[0:3]  # start from index 0 all the way till 3 (excludiing 3) --> [0,3)
print(character1)
